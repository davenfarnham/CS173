#!/usr/bin/env python2.7

#
# Check error message thrown from 2 + "hi" to
# to see if it's a type error
#

def main():
 2 + "hi"

if __name__ == '__main__':
  main()
